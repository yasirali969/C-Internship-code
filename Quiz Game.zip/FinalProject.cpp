#include<iostream>
#include<string>
#include<fstream>
using namespace std;

struct Question{
    string question;
    string option[4];
    string answer;
};
Question questions[100];
int questionCount = 0;

struct Score{
   string username;
   int marks;
};

Score scores[100];
int ScoreCount=0;

void SaveQuestion(){
    ofstream file("Quiz.txt");

    for(int i=0;i<questionCount;i++){

        file <<questions[i].question<<endl;

        for(int j=0;j<4;j++){
            file <<questions[i].option[j]<<endl;
        }

        file << questions[i].answer;
    }

    file.close();
}

void LoadQuestion(){
      ifstream file("Quiz.txt");
      if(!file){
        cout<<"No file Exit\n";
      }


           while(getline(file,questions[questionCount].question)){

                for(int j=0;j<4;j++){
                    getline(file,questions[questionCount].option[j]);
                }

                getline(file,questions[questionCount].answer);
                questionCount++;
      }
      file.close();
}
void SaveScoreToFile(){
        ofstream file("Scores.txt");

        for(int i=0;i<ScoreCount;i++){
            file <<scores[i].username << endl;
            file << scores[i].marks << endl;
        }

        file.close();
}

void LoadScores(){
     ifstream file("Scores.txt"); 

    while(getline(file,scores[ScoreCount].username)){
        file >> scores[ScoreCount].marks;
        cin.ignore();
        ScoreCount++;

    }
    file.close();
}
void SaveScore(string username,int marks){
     
     scores[ScoreCount].username=username;
     scores[ScoreCount].marks=marks;

     ScoreCount++;

     SaveScoreToFile();

}

void ViewScore(){

    for(int i=0;i<ScoreCount;i++){
        cout<<scores[i].username<<
        scores[i].marks<<endl;
    }
    
}
//  ======= Add Question =========

void AddQuestion(){
 
        cin.ignore();

     cout<<"Enter the question";
     getline(cin,questions[questionCount].question);
    

    for(int i=0;i<4;i++){
        cout<<"Enter the option "<<i<<":";
        getline(cin,questions[questionCount].option[i]);
    }


    cout<<"Enter the correct Answer\n";
    getline(cin,questions[questionCount].answer);
    

    questionCount++;
    SaveQuestion();

    cout<<"Question Added Successfully\n";
}

void DisplayQuestion(){
    for(int i=0;i<questionCount;i++){
         cout<<questions[i].question;
           for(int j=0;j<4;j++){
              cout<<questions[i].option[j];
           }

           cout<<"Answer :"<<questions[i].answer;
    }
}

void SearchQuestion(){
    DisplayQuestion();

    int num;
    cout<<"Enter the question :";
    cin>>num;

         if(num<=0|| num>questionCount){
            cout<<"Invalid Question!";
            return;
         }

            int i=num-1;
            cout<<questions[i].question;

            for(int j=0;j<4;j++){
                cout<<questions[i].option[j]<<endl;
            }

            cout<<"Answer :"<<questions[i].answer;

         }
        
    

    


void UpdateQuestion(){
     
    int num;
    cout<<"Enter the quesion number";
    cin>>num;

    if(num<=0  || num>questionCount){
        cout<<"Invalid question no";
        return;
    }

    int i=num-1;

    cout<<questions[i].question;

    for(int j=0;j<4;j++){
        cout<<questions[i].option[j];
    }

    cout << "Answer: "
         << questions[i].answer << endl;

     
          cin.ignore();

    // take new data
    cout << "\nEnter New Question: ";
    getline(cin, questions[i].question);

    for(int j = 0; j < 4; j++){
        cout << "Enter new option " << j + 1 << ": ";
        getline(cin, questions[i].option[j]);
    }

    cout << "Enter new answer: ";
    getline(cin, questions[i].answer);

    cout << "Question Updated Successfully!\n";
}

void DeleteQuestion(){
    int num;
    cout<<"Enter the question no you want to delete\n";
    cin>>num;

    if(num<=0 || num > questionCount){
        cout<<"Invalid question\n";
        return ;
    }
    int i=num-1;

    for(int j=i;j<questionCount-1;j++){
        questions[j]=questions[j+1];
    }

    questionCount--;
}

void PlayQuiz(){

    string UserName;
    string useranswer;

    cin.ignore();

    cout<<"Enter the UserName :";
    getline(cin,UserName);

    int score=0;
    for(int i=0;i<questionCount;i++){

        cout<<"Question "<< i+1 <<":"<<questions[i].question<<"\n";
         for(int j=0;j<4;j++){
            cout<<j+1<<")"<<
            questions[i].option[j]<<endl;
         }

         cout<<"Enter the Useranswer\n";
         cin>>useranswer;
         if(useranswer == questions[i].answer){
            score++;
         }
    }

    cout<<"Final Score ="<<score;
    SaveScore(UserName,score);
}

// ========= ADMIN PANEL =========
void AdminPanel(){

    int choice;

    do{

        cout << "\n===== ADMIN PANEL =====\n";
        cout << "1. Add Question\n";
        cout << "2. Display Questions\n";
        cout << "3. Search Question\n";
        cout << "4. Update Question\n";
        cout << "5. Delete Question\n";
        cout << "6. Back\n";

        cout << "Enter Choice: ";
        cin >> choice;

        switch(choice){

            case 1:
                AddQuestion();
                break;

            case 2:
                DisplayQuestion();
                break;

            case 3:
                SearchQuestion();
                break;

            case 4:
                UpdateQuestion();
                break;

            case 5:
                DeleteQuestion();
                break;

            case 6:
                cout << "Returning...\n";
                break;

            default:
                cout << "Invalid Choice\n";
        }

    }while(choice != 6);
}



int main(){

    LoadQuestion();
    LoadScores();

    int choice;

    do{

        cout << "\n====== QUIZ SYSTEM ======\n";
        cout << "1. Admin Panel\n";
        cout << "2. Play Quiz\n";
        cout << "3. View Scores\n";
        cout << "4. Exit\n";

        cout << "Enter Choice: ";
        cin >> choice;

        switch(choice){

            case 1:
                AdminPanel();
                break;

            case 2:
                PlayQuiz();
                break;

            case 3:
                ViewScore();
                break;

            case 4:
                cout << "Program Ended\n";
                break;

            default:
                cout << "Invalid Choice\n";
        }

    }while(choice != 4);

    return 0;
}              





/*#include<iostream>
#include<string>
#include<fstream>
using namespace std;

struct Question{
    string question;
    string option[4];
    string answer;
};

Question questions[100];
int questionCount = 0;

struct Score{
    string username;
    int marks;
};

Score scores[100];
int ScoreCount = 0;


// ================= SAVE QUESTIONS =================
void SaveQuestion(){
    ofstream file("Quiz.txt");

    for(int i=0;i<questionCount;i++){
        file << questions[i].question << endl;

        for(int j=0;j<4;j++){
            file << questions[i].option[j] << endl;
        }

        file << questions[i].answer << endl;
    }

    file.close();
}


// ================= LOAD QUESTIONS =================
void LoadQuestion(){
    ifstream file("Quiz.txt");

    if(!file){
        cout << "No Question File Found\n";
        return;
    }

    while(getline(file, questions[questionCount].question)){

        for(int j=0;j<4;j++){
            getline(file, questions[questionCount].option[j]);
        }

        getline(file, questions[questionCount].answer);
        questionCount++;
    }

    file.close();
}


// ================= SAVE SCORES =================
void SaveScoreToFile(){
    ofstream file("Scores.txt");

    for(int i=0;i<ScoreCount;i++){
        file << scores[i].username << endl;
        file << scores[i].marks << endl;
    }

    file.close();
}


// ================= LOAD SCORES =================
void LoadScores(){
    ifstream file("Scores.txt");

    if(!file){
        cout << "No Score File Found\n";
        return;
    }

    while(getline(file, scores[ScoreCount].username)){
        file >> scores[ScoreCount].marks;
        file.ignore();
        ScoreCount++;
    }

    file.close();
}


// ================= SAVE SINGLE SCORE =================
void SaveScore(string username, int marks){

    scores[ScoreCount].username = username;
    scores[ScoreCount].marks = marks;

    ScoreCount++;

    SaveScoreToFile();
}


// ================= VIEW SCORES =================
void ViewScore(){

    cout << "\n===== LEADERBOARD =====\n";

    for(int i=0;i<ScoreCount;i++){
        cout << scores[i].username
             << " - "
             << scores[i].marks
             << endl;
    }
}


// ================= ADD QUESTION =================
void AddQuestion(){

    if(questionCount >= 100){
        cout << "Question limit reached!\n";
        return;
    }

    cin.ignore();

    cout << "Enter the question: ";
    getline(cin, questions[questionCount].question);

    for(int i=0;i<4;i++){
        cout << "Enter option " << i+1 << ": ";
        getline(cin, questions[questionCount].option[i]);
    }

    cout << "Enter correct answer (text): ";
    getline(cin, questions[questionCount].answer);

    questionCount++;

    SaveQuestion();

    cout << "Question Added Successfully\n";
}


// ================= DISPLAY QUESTIONS =================
void DisplayQuestion(){

    for(int i=0;i<questionCount;i++){

        cout << "\nQuestion " << i+1 << endl;
        cout << questions[i].question << endl;

        for(int j=0;j<4;j++){
            cout << j+1 << ") "
                 << questions[i].option[j] << endl;
        }

        cout << "Answer: "
             << questions[i].answer << endl;
    }
}


// ================= SEARCH QUESTION =================
void SearchQuestion(){

    int num;
    cout << "Enter question number: ";
    cin >> num;

    if(num <= 0 || num > questionCount){
        cout << "Invalid Question!\n";
        return;
    }

    int i = num - 1;

    cout << questions[i].question << endl;

    for(int j=0;j<4;j++){
        cout << j+1 << ") "
             << questions[i].option[j] << endl;
    }

    cout << "Answer: "
         << questions[i].answer << endl;
}


// ================= UPDATE QUESTION =================
void UpdateQuestion(){

    int num;
    cout << "Enter question number: ";
    cin >> num;

    if(num <= 0 || num > questionCount){
        cout << "Invalid question number\n";
        return;
    }

    int i = num - 1;

    cin.ignore();

    cout << "Enter new question: ";
    getline(cin, questions[i].question);

    for(int j=0;j<4;j++){
        cout << "Enter new option " << j+1 << ": ";
        getline(cin, questions[i].option[j]);
    }

    cout << "Enter new correct answer: ";
    getline(cin, questions[i].answer);

    SaveQuestion();

    cout << "Question Updated Successfully\n";
}


// ================= DELETE QUESTION =================
void DeleteQuestion(){

    int num;
    cout << "Enter question number to delete: ";
    cin >> num;

    if(num <= 0 || num > questionCount){
        cout << "Invalid question\n";
        return;
    }

    int i = num - 1;

    for(int j=i;j<questionCount-1;j++){
        questions[j] = questions[j+1];
    }

    questionCount--;

    SaveQuestion();

    cout << "Question Deleted Successfully\n";
}


// ================= Play QUIZ =================
void PlayQuiz(){

    string username;
    string useranswer;
    int score = 0;

    cin.ignore();

    cout << "Enter Username: ";
    getline(cin, username);

    for(int i=0;i<questionCount;i++){

        cout <<"\nQuestion " << i+1 << ": "
             << questions[i].question << endl;

        for(int j=0;j<4;j++){
            cout << j+1 << ") "
                 << questions[i].option[j] << endl;
        }

        cout << "Enter your answer (text): ";
        getline(cin, useranswer);

        if(useranswer == questions[i].answer){
            score++;
        }
    }

    cout << "\nFinal Score = " << score << endl;

    SaveScore(username, score);
}


// ================= ADMIN PANEL =================
void AdminPanel(){

    int choice;

    do{
        cout << "\n===== ADMIN PANEL =====\n";
        cout << "1. Add Question\n";
        cout << "2. Display Questions\n";
        cout << "3. Search Question\n";
        cout << "4. Update Question\n";
        cout << "5. Delete Question\n";
        cout << "6. Back\n";
        cout << "Enter choice: ";

        cin >> choice;

        switch(choice){

            case 1: AddQuestion(); break;
            case 2: DisplayQuestion(); break;
            case 3: SearchQuestion(); break;
            case 4: UpdateQuestion(); break;
            case 5: DeleteQuestion(); break;
            case 6: cout << "Back...\n"; break;
            default: cout << "Invalid choice\n";
        }

    }while(choice != 6);
}


// ================= MAIN =================
int main(){

    LoadQuestion();
    LoadScores();

    int choice;

    do{
        cout << "\n====== QUIZ SYSTEM ======\n";
        cout << "1. Admin Panel\n";
        cout << "2. Play Quiz\n";
        cout << "3. View Scores\n";
        cout << "4. Exit\n";
        cout << "Enter choice: ";

        cin >> choice;

        switch(choice){

            case 1: AdminPanel(); break;
            case 2: PlayQuiz(); break;
            case 3: ViewScore(); break;
            case 4: cout << "Program Ended\n"; break;
            default: cout << "Invalid Choice\n";
        }

    }
    while(choice != 4);

    return 0;
}*/