#include<iostream>
#include<iomanip>
#include<fstream>
using namespace std;

// ================= SAVE BOOKS=================
void SaveBooks(string ID[], string BookName[], string Author[],
               int quantity[], int count){

    ofstream file("library.txt");

    // HEADER (only once)
    file << "ID        |    Book Name             | Author               | Qty" << endl;
    file << "-------------------------------------------------------------------" << endl;

    for(int i=0; i<count; i++){
        file << left
             << setw(10) << ID[i] << " | "
             << setw(24) << BookName[i] << " | "
             << setw(20) << Author[i] << " | "
             << setw(3)  << quantity[i] << endl;
    }

    file.close();
}

// ================= LOAD BOOKS=================
void LoadBooks(string ID[], string BookName[], string Author[], int quantity[], int &count){

    ifstream file("library.txt");

    count = 0;

    while(getline(file, ID[count])){

        getline(file, BookName[count]);
        getline(file, Author[count]);

        file>>quantity[count];
        file.ignore();

        count++;
    }

    file.close();
}

// ================= ADD BOOKS =================
void Addbook(string ID[],string BookName[],string Author[],int quantity[],int &count){

    cin.ignore();

    cout<<"Enter Book ID: ";
    getline(cin,ID[count]);

    cout<<"Enter Book Name: ";
    getline(cin,BookName[count]);

    cout<<"Enter Author: ";
    getline(cin,Author[count]);

    cout<<"Enter Quantity: ";
    cin>>quantity[count];

    count++;

    cout<<"Book Added Successfully!\n";
}

// ================= DISPLAY BOOKS=================
void DisplayBook(string ID[],string BookName[],string Author[],int quantity[],int count){

    cout<<"\n===== ALL BOOKS =====\n";

    cout<<left
        <<setw(10)<<"ID"
        <<setw(25)<<"Book Name"
        <<setw(20)<<"Author"
        <<setw(10)<<"Qty"<<endl;

    for(int i=0;i<count;i++){

        cout<<left
            <<setw(10)<<ID[i]
            <<setw(25)<<BookName[i]
            <<setw(20)<<Author[i]
            <<setw(10)<<quantity[i]<<endl;
    }
}

// ================= SEARCH BOOK =================
void SearchBook(string ID[],string BookName[],string Author[],int quantity[],int count){

    cin.ignore();

    string id;
    cout<<"Enter Book ID: ";
    getline(cin,id);

    bool found=false;

    for(int i=0;i<count;i++){
        if(id==ID[i]){
            found=true;

            cout<<"\nBOOK FOUND:\n";
            cout<<"Name: "<<BookName[i]<<endl;
            cout<<"Author: "<<Author[i]<<endl;
            cout<<"Qty: "<<quantity[i]<<endl;
        }
    }

    if(!found) cout<<"Book Not Found\n";
}

// ================= ISSUE Book =================
void IssueBook(string ID[],int count,string BookName[],int quantity[]){

    cin.ignore();

    string id,student;

    cout<<"Enter Student Name: ";
    getline(cin, student);

    cout<<"Enter Book ID: ";
    getline(cin,id);

    for(int i=0;i<count;i++){
        if(id==ID[i]){

            if(quantity[i]>0){
                quantity[i]--;

                cout<<"Book Issued to "<<student<<endl;
            }
            else{
                cout<<"Out of Stock\n";
            }
            return;
        }
    }

    cout<<"Book Not Found\n";
}

// ================= RETURN BOOK =================
void ReturnBook(string ID[],int count,int quantity[]){

    cin.ignore();

    string id;
    cout<<"Enter Book ID to Return: ";
    getline(cin,id);

    for(int i=0;i<count;i++){
        if(id==ID[i]){
            quantity[i]++;
            cout<<"Book Returned Successfully\n";
            return;
        }
    }

    cout<<"Book Not Found\n";
}

// ================= DELETE BOOK =================
void DeleteBook(string ID[], string BookName[],string Author[], int quantity[], int &count){

    cin.ignore();

    string id;
    cout<<"Enter Book ID to Delete: ";
    getline(cin,id);

    for(int i=0;i<count;i++){
        if(id==ID[i]){

            for(int j=i;j<count-1;j++){
                ID[j]=ID[j+1];
                BookName[j]=BookName[j+1];
                Author[j]=Author[j+1];
                quantity[j]=quantity[j+1];
            }

            count--;
            cout<<"Book Deleted Successfully\n";
            return;
        }
    }

    cout<<"Book Not Found\n";
}

// ================= MAIN =================
int main(){

    string ID[100];
	string BookName[100];
	string Author[100];
    int quantity[100];

    int count=0;

    LoadBooks(ID,BookName,Author,quantity,count);

    int choice;

    do{

        cout<<"\n===== LIBRARY MENU =====\n";
        cout<<"1. Add Book\n";
        cout<<"2. Display Books\n";
        cout<<"3. Search Book\n";
        cout<<"4. Issue Book\n";
        cout<<"5. Return Book\n";
        cout<<"6. Delete Book\n";
        cout<<"7. Exit\n";

        cout<<"Enter choice: ";
        cin>>choice;

        switch(choice){

            case 1:
            	cout<<"====== Add Books ======\n";
                Addbook(ID,BookName,Author,quantity,count);
                SaveBooks(ID,BookName,Author,quantity,count);
                break;

            case 2:
            	cout<<"====== Display Books ======\n";
                DisplayBook(ID,BookName,Author,quantity,count);
                break;

            case 3:
                cout<<"====== Search Book ======\n";
                SearchBook(ID,BookName,Author,quantity,count);
                break;

            case 4:
            	cout<<"====== Issue Book ======\n ";
                IssueBook(ID,count,BookName,quantity);
                SaveBooks(ID,BookName,Author,quantity,count);
                break;

            case 5:
            	cout<<"====== Return Book ======\n ";
                ReturnBook(ID,count,quantity);
                SaveBooks(ID,BookName,Author,quantity,count);
                break;

            case 6:
            	cout<<"====== Delete Book ======\n ";
                DeleteBook(ID,BookName,Author,quantity,count);
                SaveBooks(ID,BookName,Author,quantity,count);
                break;

            case 7:
                cout<<"Program Closed\n";
                break;

            default:
                cout<<"Invalid Choice\n";
        }

    }while(choice!=7);

    return 0;
}