#include<iostream>
using namespace std;
int addRecord(string name[100],int rollNo[100],int marks[100],int count){
    
    int n;
    cout<<"How many record do you want to add :";
    cin>>n;
    for(int i=0;i<n;i++){
        cout<<"=======================\n";
        cout<<"Add Student :"<<i+1<<"\n"; 
        cout<<"=======================\n";
        cout<<"Enter the name : ";
        cin>>name[count];
        cout<<"Enter the rollNo : ";
        cin>>rollNo[count];
        cout<<"Enter the marks : ";
        cin>>marks[count];

         count++;
    }
    return count;
}

void DisplayRecord(int count1,string name[100],int rollNo[100],int marks[100]){
       for(int i=0;i<count1;i++){
            cout<<name[i]<<" "<<rollNo[i]<<" "<<marks[i];
            cout<<"\n";
            
        }
}
void searchRecord(string name[100],int rollNo[100],int marks[100]){
    int n;
    cout<<"Search by rollNo :";
    cin>>n;

    for(int i=0;i<100;i++){
    if(n==rollNo[i]){
     cout<<"Student Name :"<<name[i]<<"\n";
     cout<<"Student RollNo :"<<rollNo[i]<<"\n";
     cout<<"Student marks :"<<marks[i]<<"\n";
     break;
    }
}
}
    

int main(){
    string name[100];
    int rollNo[100];
    int marks[100];
    int count=0;
    int choice;

    do{

    cout<<"======================\n";
    cout<<"1)Add Student Record\n";
    cout<<"2)Display Students Record\n";
    cout<<"3)Search Student Record\n";
    cout<<"4)Exit\n";
    cout<<"======================\n";

    cout<<"Enter the choice :";
    cin>>choice;
    if(choice==1){
        cout<<"===Add Student Record===\n";
        count =addRecord(name,rollNo,marks,count);
    }
    else if(choice==2){
    cout<<"===Display Students Record===\n";
    DisplayRecord(count,name ,rollNo,marks);
    }
    else if(choice==3){
    cout<<"===Search Student Record===\n";
    searchRecord(name,rollNo,marks);
    }
    else if(choice==4){
        cout<<"Exiting program\n";
    }
    else{
        cout<<"Invalid choice";
    }
     

}while(choice!=4);
    
return 0;
    }

    

